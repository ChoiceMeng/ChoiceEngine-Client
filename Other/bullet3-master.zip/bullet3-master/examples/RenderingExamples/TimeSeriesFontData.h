#ifndef TIME_SERIES_FONT_DATA_H
#define TIME_SERIES_FONT_DATA_H

extern unsigned char sTimeSeriesFontData[];

#endif//TIME_SERIES_FONT_DATA_H
